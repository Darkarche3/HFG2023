from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name = "all-projects"), #our-domain.com/projects
    path('<slug:project_slug>/success', views.confirm_registration, name = "confirm-registration"),
    path('/<slug:project_slug>', views.project_details, name = "project-detail"), #our-domain.com/projects/a-second-project <dynamic-path-segment>
] 