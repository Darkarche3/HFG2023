from django.shortcuts import render, redirect

from .models import Project, Participant
from .forms import RegistrationForm
# Create your views here.

def index(request):
    projects = Project.objects.all()
    return render(request, 'projects/index.html', {
        'show_projects': True,
        'projects': projects
    })

def project_details(request, project_slug):
    try:
        selected_project = Project.objects.get(slug=project_slug)
        if request.method == "GET":
            
            registration_form = RegistrationForm()
            return render(request, 'projects/project-details.html', {
            'project_found': True,
            'project': selected_project,
            'form': registration_form,
        })
        else:
            registration_form = RegistrationForm(request.POST)
            if registration_form.is_valid():
                user_email = registration_form.cleaned_data["email"]
                participant, _ = Participant.objects.get_or_create(email=user_email)
                selected_project.participants.add(participant)
                return redirect("confirm-registration", project_slug=project_slug)


    except Exception as exc:
        return render(request, "projects/project-details.html", {
            'project_found': False
        })

def confirm_registration(request, project_slug):
    project = Project.objects.get(slug=project_slug)
    return render(request, "projects/registration-success.html", {
        'organizer_email': project.organizer_email
    })
