from django import forms
from .models import Participant

class RegistrationForm(forms.Form):
    name = forms.CharField(label = "Your name")
    email = forms.EmailField(label = "Your email")
    

class ProjectRequestForm(forms.Form):
    title = forms.CharField(max_length = 200)
    organizer_email = forms.EmailField()
    date = forms.DateField()
    description = forms.CharField(max_length = 1000, widget = forms.Textarea(attrs = {'rows': 20, 'cols': 70}))
    project_image = forms.ImageField()
    location = forms.CharField(max_length = 200)

class CollaborationForm(forms.ModelForm):
    class Meta:
        model = Participant
        fields = []
        
    members = forms.ModelMultipleChoiceField(
        queryset = Participant.objects.all().order_by("name"),
        widget = forms.CheckboxSelectMultiple
        )
    