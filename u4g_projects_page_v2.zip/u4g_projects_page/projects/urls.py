from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name = "all-projects"), #our-domain.com/projects
    path('request-success', views.request_success, name = "request-success"),
    path('request-project', views.request_project, name = "request-project"),
    path('collaborations/', views.collaborations, name = "collaborations"),
    path('collabtable', views.collabtable, name = "collabtable"),
    path('/<slug:project_slug>', views.project_details, name = "project-detail"), #our-domain.com/projects/a-second-project <dynamic-path-segment>
    path('<slug:project_slug>/success', views.confirm_registration, name = "confirm-registration"),
] 